# Copyright (c) 2022 Microsoft
# Licensed under The MIT License [see LICENSE for details]
